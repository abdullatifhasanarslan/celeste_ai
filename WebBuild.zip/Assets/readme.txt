Dosya boyutu çok büyük olduğu için ninova kabul etmiyor. Bu sebeple sadece script dosyalarını koyuyorum ve github linkini bırakıyorum https://github.com/abdullatifhasanarslan/celeste_ai
